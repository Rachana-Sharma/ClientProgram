package com.service.model;

public class Output {
	private int result;

	/**
	 * @param result
	 */
	public Output(int result) {
		
		this.result = result;
	}

	/**
	 * 
	 */
	public Output() {
		
	}

	/**
	 * @return the result
	 */
	public int getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(int result) {
		this.result = result;
	}
	

}
